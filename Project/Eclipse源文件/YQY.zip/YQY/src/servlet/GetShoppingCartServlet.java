package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.GameDao;
import dao.UserDao;
import entity.GameBean;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class GetShoppingCartServlet
 */
@WebServlet("/GetShoppingCartServlet")
public class GetShoppingCartServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetShoppingCartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");
        int user_id = Integer.parseInt(request.getParameter("user_id"));
        UserDao udao = new UserDao();
        GameDao gdao = new GameDao();
        JSONArray ja = new JSONArray();
        List<Integer> gameid = new ArrayList<>();
        gameid = udao.getShoppingCart(user_id);
        if (gameid.size() > 0) {
            for (int i = 0; i < gameid.size(); i++) {
                System.out.println(gameid.get(i));
                JSONObject jo = new JSONObject();
                GameBean gbean = new GameBean();
                gbean = gdao.getGameById(gameid.get(i));
                jo.put("game_id", gbean.getGame_id());
                jo.put("game_name", gbean.getGame_name());
                jo.put("game_price", gbean.getGame_price());
                jo.put("game_image", gbean.getGame_image());
                ja.add(jo);
            }
        }
        PrintWriter out = response.getWriter();
        out.print(ja);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }

}
