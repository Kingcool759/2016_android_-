package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.User_detailsDao;

/**
 * Servlet implementation class MyInformationServlet
 */
@WebServlet("/MyInformationServlet")
public class MyInformationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyInformationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");
        String id = request.getParameter("user_id");
        String user_nickname = "";
        String user_sex = "";
        String user_age = "";
        String user_school = "";
        user_nickname = request.getParameter("unickname");
        user_sex = request.getParameter("usex");
        user_age = request.getParameter("uage");
        user_school = request.getParameter("uschool");
        User_detailsDao uddao = new User_detailsDao();
        uddao.saveDetails(Integer.parseInt(id), user_nickname, user_sex, user_age, user_school);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }

}
