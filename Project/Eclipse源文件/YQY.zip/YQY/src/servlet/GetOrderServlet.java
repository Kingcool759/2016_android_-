package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.OrdersDao;
import entity.OrdersBean;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class GetOrderServlet
 */
@WebServlet("/GetOrderServlet")
public class GetOrderServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetOrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");
        String order_state = request.getParameter("order_state");
        PrintWriter out = response.getWriter();
        int user_id = Integer.parseInt(request.getParameter("user_id"));
        List<OrdersBean> list = new ArrayList<>();
        OrdersDao odao = new OrdersDao();
        list = odao.getOrder(user_id, order_state);
        JSONArray ja = new JSONArray();
        for (int i = 0; i < list.size(); i++) {
            OrdersBean obean = list.get(i);
            JSONObject jo = new JSONObject();
            jo.put("order_image", obean.getOrder_image());
            jo.put("order_id", obean.getOrder_id());
            jo.put("add_time", obean.getAdd_time());
            jo.put("sumprice", obean.getSumprice());
            ja.add(jo);
        }

        out.print(ja);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }

}
