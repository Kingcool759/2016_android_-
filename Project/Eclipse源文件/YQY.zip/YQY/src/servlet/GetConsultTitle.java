package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ConsultDao;
import entity.ConsultBean;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class GetConsultTitle
 */
@WebServlet("/GetConsultTitle")
public class GetConsultTitle extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetConsultTitle() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html; charset=UTF-8");
        ConsultDao cd = new ConsultDao();
        String etstr = request.getParameter("etstr");
        List<ConsultBean> list = cd.MoHuQueryConsult(etstr);
        JSONArray ja = new JSONArray();
        for (int i = 0; i < list.size(); i++) {
            ConsultBean cbean = list.get(i);
            JSONObject jo = new JSONObject();
            jo.put("consult_id", cbean.getConsultId());
            jo.put("consult_title", cbean.getConsultTitle());
            ja.add(jo);
        }
        PrintWriter out = response.getWriter();
        out.println(ja);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }

}
