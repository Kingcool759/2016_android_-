package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.OrdersDao;
import dao.RepertoryDao;

/**
 * Servlet implementation class PayOrderServlet
 */
@WebServlet("/PayOrderServlet")
public class PayOrderServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public PayOrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");
        int user_id = Integer.parseInt(request.getParameter("user_id"));
        int order_id = Integer.parseInt(request.getParameter("order_id"));
        OrdersDao odao = new OrdersDao();
        RepertoryDao rdao = new RepertoryDao();
        String order_state = odao.getOrderState(user_id, order_id);
        PrintWriter out = response.getWriter();
        // 判断是否支付过
        if (order_state.equals("已支付")) {
            out.print("请勿重复购买！");
        } else {
            List<Integer> gameidlist = odao.getOrderGame(user_id, order_id);
            // 判断支付的游戏库存中有没有
            List<Integer> r_gid = rdao.getRepertory(user_id);
            int x = 0;
            for (int id : r_gid) {
                if (gameidlist.contains(id)) {
                    x = 1;
                }
            }

            if (x == 0) {
                // 支付并将游戏加入库存
                odao.payOrder(user_id, order_id);
                for (int i = 0; i < gameidlist.size(); i++) {
                    rdao.addRepertory(gameidlist.get(i), user_id);
                    System.out.println("glt" + gameidlist.get(i));
                }
                out.print("支付成功！");
            } else {
                // 取消订单
                odao.deleteOrder(user_id, order_id);
                odao.deleteOrderDetail(user_id, order_id);
                out.print("存在库存中有的游戏，请重新选择游戏！");
            }
        }

    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }

}
