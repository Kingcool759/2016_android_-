package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Consult_detailsDao;
import entity.ConsultBean;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class GetConsultDetailsServlet
 */
@WebServlet("/GetConsultDetailsServlet")
public class GetConsultDetailsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetConsultDetailsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");
        // 从客户端获取资讯列表的id属性
        System.out.print("\nID" + request.getParameter("id"));
        int id = Integer.parseInt(request.getParameter("id"));

        // 从数据库查询数据
        ConsultBean c = new ConsultBean();
        Consult_detailsDao cd = new Consult_detailsDao();
        // 根据从客户端获取到的资讯列表id去数据库查找对应id的数据
        c = cd.QueryConsult(id);

        // 创建json对象
        JSONObject jo = new JSONObject();
        // 将数据以key/value方式存入对象中
        // jo.put("id", c.getConsultId());
        jo.put("title", c.getConsultTitle());
        jo.put("content", c.getConsultContent());
        jo.put("image", c.getConsultImage());
        System.out.println("" + c.getConsultImage());
        String jsonStr = jo.toString();

        PrintWriter out = response.getWriter();
        out.println(jsonStr);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }

}
