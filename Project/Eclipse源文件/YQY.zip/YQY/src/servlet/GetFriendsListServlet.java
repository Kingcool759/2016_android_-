package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.FriendsDao;
import entity.FriendsBean;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class GetFriendsListServlet
 */
@WebServlet("/GetFriendsListServlet")
public class GetFriendsListServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetFriendsListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");
        FriendsDao fdao = new FriendsDao();
        // 用数组方式存储JSONObject对象
        JSONArray ja = new JSONArray();
        List<FriendsBean> list = fdao.SelectFriendsList();
        for (int i = 0; i < list.size(); i++) {
            FriendsBean fbean = list.get(i);
            JSONObject jo = new JSONObject();
            jo.put("friends_id", fbean.getFriendsId());
            jo.put("friends_image", fbean.getFriendsImage());
            jo.put("friends_name", fbean.getFriendsName());
            jo.put("chat_time", fbean.getChatTime());
            ja.add(jo);
            // SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
            // String add_time = df.format(new Date());
        }
        System.out.println("gfl" + list.size());
        PrintWriter out = response.getWriter();
        out.println(ja);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }

}
