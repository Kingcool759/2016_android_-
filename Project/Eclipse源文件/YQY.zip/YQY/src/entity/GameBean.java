package entity;

public class GameBean {
    private int game_id;
    private String game_name;
    private String game_price;
    private String game_classification;
    private String game_image;
    private String game_introduction;
    private String game_bimage;

    public GameBean() {
        super();
        // TODO Auto-generated constructor stub
    }

    public GameBean(int game_id, String game_name, String game_price, String game_classification, String game_image,
        String game_introduction, String game_bimage) {
        super();
        this.game_id = game_id;
        this.game_name = game_name;
        this.game_price = game_price;
        this.game_classification = game_classification;
        this.game_image = game_image;
        this.game_introduction = game_introduction;
        this.game_bimage = game_bimage;
    }

    public int getGame_id() {
        return game_id;
    }

    public void setGame_id(int game_id) {
        this.game_id = game_id;
    }

    public String getGame_name() {
        return game_name;
    }

    public void setGame_name(String game_name) {
        this.game_name = game_name;
    }

    public String getGame_price() {
        return game_price;
    }

    public void setGame_price(String game_price) {
        this.game_price = game_price;
    }

    public String getGame_classification() {
        return game_classification;
    }

    public void setGame_classification(String game_classification) {
        this.game_classification = game_classification;
    }

    public String getGame_image() {
        return game_image;
    }

    public void setGame_image(String game_image) {
        this.game_image = game_image;
    }

    public String getGame_introduction() {
        return game_introduction;
    }

    public void setGame_introduction(String game_introduction) {
        this.game_introduction = game_introduction;
    }

    public String getGame_bimage() {
        return game_bimage;
    }

    public void setGame_bimage(String game_bimage) {
        this.game_bimage = game_bimage;
    }

}
