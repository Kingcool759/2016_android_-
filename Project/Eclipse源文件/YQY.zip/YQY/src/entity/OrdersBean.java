package entity;

public class OrdersBean {
    private int order_id;
    private int user_id;
    private String add_time;
    private String order_state;
    private String order_image;
    private int sumprice;

    public OrdersBean() {
        super();
        // TODO Auto-generated constructor stub
    }

    public String getOrder_image() {
        return order_image;
    }

    public void setOrder_image(String order_image) {
        this.order_image = order_image;
    }

    public OrdersBean(int order_id, int user_id, String add_time, String order_state, String order_image,
        int sumprice) {
        super();
        this.order_id = order_id;
        this.user_id = user_id;
        this.add_time = add_time;
        this.order_state = order_state;
        this.order_image = order_image;
        this.sumprice = sumprice;
    }

    public int getSumprice() {
        return sumprice;
    }

    public void setSumprice(int sumprice) {
        this.sumprice = sumprice;
    }

    public int getOrder_id() {
        return order_id;
    }

    public void setOrder_id(int order_id) {
        this.order_id = order_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getAdd_time() {
        return add_time;
    }

    public void setAdd_time(String add_time) {
        this.add_time = add_time;
    }

    public String getOrder_state() {
        return order_state;
    }

    public void setOrder_state(String order_state) {
        this.order_state = order_state;
    }

}
