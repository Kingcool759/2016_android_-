package entity;

public class ConsultBean {
    private int consultId;
    private String consultTitle;
    private String consultContent;
    private String consultIcon;
    private String consultImage;

    public int getConsultId() {
        return consultId;
    }

    public void setConsultId(int consultId) {
        this.consultId = consultId;
    }

    public String getConsultTitle() {
        return consultTitle;
    }

    public void setConsultTitle(String consultTitle) {
        this.consultTitle = consultTitle;
    }

    public String getConsultContent() {
        return consultContent;
    }

    public void setConsultContent(String consultContent) {
        this.consultContent = consultContent;
    }

    public String getConsultIcon() {
        return consultIcon;
    }

    public void setConsultIcon(String consultIcon) {
        this.consultIcon = consultIcon;
    }

    public String getConsultImage() {
        return consultImage;
    }

    public void setConsultImage(String consultImage) {
        this.consultImage = consultImage;
    }

    public ConsultBean() {
        super();
        // TODO Auto-generated constructor stub
    }

    public ConsultBean(int consultId, String consultTitle, String consultContent, String consultIcon,
        String consultImage) {
        this.consultId = consultId;
        this.consultTitle = consultTitle;
        this.consultContent = consultContent;
        this.consultIcon = consultIcon;
        this.consultImage = consultImage;
    }

}
