package entity;

public class FriendsBean {
    private int friendsId;
    private String friendsImage;
    private String friendsName;
    private String chatTime;

    public FriendsBean(int friendsId, String friendsImage, String friendsName, String chatTime) {
        this.friendsId = friendsId;
        this.friendsImage = friendsImage;
        this.friendsName = friendsName;
        this.chatTime = chatTime;
    }

    public FriendsBean() {
        super();
        // TODO Auto-generated constructor stub
    }

    public int getFriendsId() {
        return friendsId;
    }

    public void setFriendsId(int friendsId) {
        this.friendsId = friendsId;
    }

    public String getFriendsImage() {
        return friendsImage;
    }

    public void setFriendsImage(String friendsImage) {
        this.friendsImage = friendsImage;
    }

    public String getFriendsName() {
        return friendsName;
    }

    public void setFriendsName(String friendsName) {
        this.friendsName = friendsName;
    }

    public String getChatTime() {
        return chatTime;
    }

    public void setChatTime(String chatTime) {
        this.chatTime = chatTime;
    }

}
