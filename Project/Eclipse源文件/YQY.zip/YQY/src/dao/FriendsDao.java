package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import database.DBUtil;
import entity.FriendsBean;

public class FriendsDao {
    /*
     *  查询listview中好友列表
     */
    public List<FriendsBean> SelectFriendsList() {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        String sql_select = "select * from friends";
        List<FriendsBean> list = new ArrayList<>();
        try {
            pstmt = conn.prepareStatement(sql_select);
            ResultSet rs = pstmt.executeQuery(); // 获取结果集
            while (rs.next()) {
                // 查到了获取数据
                FriendsBean fb = new FriendsBean();
                fb.setFriendsId(rs.getInt("friends_id"));
                fb.setFriendsImage(rs.getString("friends_image"));
                fb.setFriendsName(rs.getString("friends_name"));
                fb.setChatTime(rs.getString("chat_time"));
                list.add(fb);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return list;
    }

    /**
     * 根据f_id查找f_image
     */
    public String selectFriendsImage(int f_id) {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        String friends_image = "";
        String selectsql = "select * from friends where f_id='" + f_id + "'";
        try {
            pstmt = conn.prepareStatement(selectsql);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                friends_image = rs.getString("friends_image");
            } else {
                return "未找到用户头像！";
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return friends_image;
    }
}
