package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import database.DBUtil;

public class RepertoryDao {

    /**
     * 根据id加入库存
     */
    public void addRepertory(int game_id, int user_id) {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        String sql = "Insert into repertory (user_id,game_id) values (?,?)";
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, user_id);
            pstmt.setInt(2, game_id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    /**
     * 根据user_id查看库存
     */
    public List<Integer> getRepertory(int user_id) {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        String sql = "Select * from repertory where user_id='" + user_id + "'";
        List<Integer> gameidlist = new ArrayList<>();
        try {
            pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                gameidlist.add(rs.getInt("game_id"));
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return gameidlist;
    }

    /**
     * 根据user_id和分类查看库存
     */
    public List<Integer> getRepertory(int user_id, String classification) {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        String sql = "Select * from repertory where user_id='" + user_id + "'and classification";
        List<Integer> gameidlist = new ArrayList<>();
        try {
            pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                gameidlist.add(rs.getInt("game_id"));
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return gameidlist;
    }
}
