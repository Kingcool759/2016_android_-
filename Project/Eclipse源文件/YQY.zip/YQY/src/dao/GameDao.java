package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import database.DBUtil;
import entity.GameBean;

public class GameDao {
    /**
     * 根据分类查找游戏
     */
    public List<GameBean> selectGame(String game_classification) {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        List<GameBean> list = new ArrayList<>();
        String sql = "select * from games where game_classification='" + game_classification + "'";
        try {
            pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                GameBean gb = new GameBean(rs.getInt("game_id"), rs.getString("game_name"), rs.getString("game_price"),
                    rs.getString("game_classification"), rs.getString("game_image"), rs.getString("game_introduction"),
                    rs.getString("game_bimage"));
                list.add(gb);
            }

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return list;
    }

    /**
     * 根据id查找游戏
     */
    public GameBean getGameById(int id) {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        GameBean gb = new GameBean();
        String sql = "select * from games where game_id='" + id + "'";
        try {
            pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                gb = new GameBean(rs.getInt("game_id"), rs.getString("game_name"), rs.getString("game_price"),
                    rs.getString("game_classification"), rs.getString("game_image"), rs.getString("game_introduction"),
                    rs.getString("game_bimage"));
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return gb;
    }

    /**
     * 根据id查找购物车里的游戏
     */
    public List<Integer> getShoppingCartGameByUserId(int user_id) {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        List<Integer> gameidlist = new ArrayList<>();
        String sql = "select game_id from shoppingcart where user_id='" + user_id + "'";
        try {
            pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                gameidlist.add(rs.getInt("game_id"));
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return gameidlist;
    }

    /**
     * 根据id删除购物车里的游戏
     */
    public void deleteShoppingCartGameById(int game_id, int user_id) {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        String sql = "delete from shoppingcart where game_id='" + game_id + "'" + "and user_id='" + user_id + "'";
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    /**
     * 根据id删除游戏
     */
    public void deleteCollectionGameById(int user_id, int game_id) {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        String sql = "delete from collection where game_id='" + game_id + "'and user_id='" + user_id + "'";
        try {
            // 查找收藏列表是否存在相应游戏
            pstmt = conn.prepareStatement(sql);
            pstmt.executeUpdate();

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}
