package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import database.DBUtil;
import entity.ConsultBean;

public class Consult_detailsDao {
    public ConsultBean QueryConsult(int c_id) {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        String sql_select = "select* from consult where consult_id='" + c_id + "'";

        ConsultBean cs = new ConsultBean();
        try {
            pstmt = conn.prepareStatement(sql_select);
            ResultSet rs = pstmt.executeQuery(); // 获取结果集
            if (rs.next()) {
                // 查到了获取数据
                cs.setConsultTitle(rs.getString("consult_title"));
                cs.setConsultContent(rs.getString("consult_content"));
                cs.setConsultImage(rs.getString("consult_image"));
            } else {
                System.out.println("数据库中未找到这条数据！");
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return cs;

    }
}
