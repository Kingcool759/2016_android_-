package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import database.DBUtil;
import entity.OrdersBean;

public class OrdersDao {
    /**
     * 加入订单并返回订单ID
     */
    public int addOrder(int user_id, String add_time, String order_image, int sumprice) {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        String sql =
            "insert into orders(order_id,user_id,add_time,order_state,order_image,sumprice)values(?,?,?,?,?,?)";
        String sql2 = "select * from orders";
        int count = 0;
        try {
            // 找到最小的可以接收的order_id
            pstmt = conn.prepareStatement(sql2);
            ResultSet r = pstmt.executeQuery();
            while (r.next() && count + 1 == r.getInt("order_id")) {
                count = r.getInt("order_id");
            }
            count++;
            // 加入新用户
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, count);
            pstmt.setInt(2, user_id);
            pstmt.setString(3, add_time);
            pstmt.setString(4, "未付款");
            pstmt.setString(5, order_image);
            pstmt.setInt(6, sumprice);
            pstmt.executeUpdate();

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return count;
    }

    /**
     * 加入订单详情
     */
    public void addOrderDetail(int order_id, int user_id, int game_id) {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        String sql = "insert into orders_details (order_id,user_id,game_id,order_state) values(?,?,?,?)";
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, order_id);
            pstmt.setInt(2, user_id);
            pstmt.setInt(3, game_id);
            pstmt.setString(4, "未付款");
            pstmt.executeUpdate();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    /**
     * 根据user_id获得用户订单
     */
    public List<OrdersBean> getOrder(int user_id, String order_state) {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        List<OrdersBean> list = new ArrayList<>();
        String sql = null;
        if (order_state.equals("全部订单")) {
            sql = "select * from orders where user_id='" + user_id + "'";
        } else {
            sql = "select * from orders where user_id='" + user_id + "'and order_state='" + order_state + "'";
        }

        try {
            pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                OrdersBean obean = new OrdersBean(rs.getInt("order_id"), user_id, rs.getString("add_time"),
                    rs.getString("order_state"), rs.getString("order_image"), rs.getInt("sumprice"));
                list.add(obean);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return list;
    }

    /**
     * 删除订单
     */
    public void deleteOrder(int user_id, int order_id) {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        String sql = "delete from orders where order_id='" + order_id + "'" + "and user_id='" + user_id + "'";
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    /**
     * 删除订单详情
     */
    public void deleteOrderDetail(int user_id, int order_id) {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        String sql = "delete from orders_details where order_id='" + order_id + "'" + "and user_id='" + user_id + "'";
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    /**
     * 支付订单
     */
    public void payOrder(int user_id, int order_id) {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        String sql =
            "Update orders set order_state ='已支付'where order_id='" + order_id + "'" + "and user_id='" + user_id + "'";
        String sql2 = "Update orders_details set order_state ='已支付'where order_id='" + order_id + "'" + "and user_id='"
            + user_id + "'";
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.executeUpdate();
            pstmt = conn.prepareStatement(sql2);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    /**
     * 获得订单状态
     */
    public String getOrderState(int user_id, int order_id) {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        String sql = "Select * from orders where order_id='" + order_id + "'" + "and user_id='" + user_id + "'";
        String order_state = "";
        try {
            pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                order_state = rs.getString("order_state");
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return order_state;
    }

    /**
     * 通过order_id获得game_id
     */
    public List<Integer> getOrderGame(int user_id, int order_id) {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        String sql = "Select * from orders_details where order_id='" + order_id + "'" + "and user_id='" + user_id + "'";
        List<Integer> gameidlist = new ArrayList<>();
        try {
            pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                gameidlist.add(rs.getInt("game_id"));
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return gameidlist;
    }
}
