package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import database.DBUtil;
import entity.ConsultBean;

public class ConsultDao {
    /*
     *  查询listview中资讯条数 
     */
    public List<ConsultBean> SelectConsult() {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        String sql_select = "select * from consult";
        List<ConsultBean> list = new ArrayList<>();

        try {
            pstmt = conn.prepareStatement(sql_select);
            ResultSet rs = pstmt.executeQuery(); // 获取结果集
            while (rs.next()) {
                // 查到了获取数据
                ConsultBean cs = new ConsultBean();
                cs.setConsultId(rs.getInt("consult_id"));
                cs.setConsultTitle(rs.getString("consult_title"));
                cs.setConsultIcon(rs.getString("consult_icon"));
                list.add(cs);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return list;

    }

    // 模糊匹配
    public List<ConsultBean> MoHuQueryConsult(String etstr) {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        String sql_select = "select * from consult where consult_title like '%" + etstr + "%'";
        List<ConsultBean> list = new ArrayList<>();
        try {
            pstmt = conn.prepareStatement(sql_select);
            ResultSet rs = pstmt.executeQuery(); // 获取结果集
            while (rs.next()) {
                // 查到了获取数据
                ConsultBean cs = new ConsultBean();
                cs.setConsultId(rs.getInt("consult_id"));
                cs.setConsultTitle(rs.getString("consult_title"));
                list.add(cs);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return list;
    }
}
