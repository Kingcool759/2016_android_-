package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import database.DBUtil;

public class UserDao {
    /**
     * 注册用户方法(返回-1表示该用户已存在，返回1表示注册成功);
     */
    public int adduser(String user_name, String password, String user_phone) {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        String sql = "insert user(user_id,user_name,password,user_phone)values(?,?,?,?)";
        String sql2 = "select * from user";
        String sql_select = "select * from user where user_name='" + user_name + "'";
        try {
            // 查找有没有重复的user_name
            pstmt = conn.prepareStatement(sql_select);
            ResultSet r2 = pstmt.executeQuery();
            if (r2.next()) {
                return -1;
            }
            // 找到最小的可以接收的user_id
            int count = 0;
            pstmt = conn.prepareStatement(sql2);
            ResultSet r = pstmt.executeQuery();
            while (r.next() && count + 1 == r.getInt("user_id")) {
                count = r.getInt("user_id");
            }
            count++;
            // 加入新用户
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, count);
            pstmt.setString(2, user_name);
            pstmt.setString(3, password);
            pstmt.setString(4, user_phone);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return 1;
    }

    /**
     * 根据user_name查找user_id
     */
    public int selectuid(String user_name) {
        Connection conn = DBUtil.getConnection();
        int user_id = 0;
        PreparedStatement pstmt = null;
        String sql = "select * from user where user_name='" + user_name + "'";
        try {
            pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                user_id = rs.getInt("user_id");
            } else {
                return -1;
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return user_id;
    }

    /**
     * 验证登录
     */
    public String verifyUser(String user_name, String password) {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        String sql = "select user_name,password from user where user_name='" + user_name + "'";
        try {
            pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                if (rs.getString("password").equals(password)) {
                    return "登录成功！正在跳转......";
                } else {
                    return "密码错误！请重新输入";
                }
            } else {
                return "该用户不存在！";
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return "";
    }

    /*
     * 查询数据库用户名和手机号匹配 
     */
    public String QeuryUserPhone(String rename, String rephone) {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        String sql = "select user_phone from user where user_name='" + rename + "'";
        try {
            pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                if (rs.getString("user_phone").equals(rephone)) {
                    return "用户名与绑定手机号匹配！";
                } else {
                    return "用户名与所绑定手机号不匹配！";
                }
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return "";
    }

    /**
     * 重置用户密码
     */
    public String ReplaceUserPwd(String rename, String newpwd) {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        String sql = "update user set password = ? where user_name='" + rename + "'";

        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, newpwd);
            pstmt.executeUpdate();
            return "密码重置成功！";
            // 重置密码

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return "";
    }

    /**
     * 加入购物车操作
     */
    public String addShoppingCart(int user_id, int game_id) {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        String sql = "select * from shoppingcart where user_id='" + user_id + "'and game_id='" + game_id + "'";
        String sql_add = "insert into shoppingcart values(" + user_id + "," + game_id + ")";
        try {
            // 查找购物车是否存在相应游戏
            pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            if (!rs.next()) {
                pstmt = conn.prepareStatement(sql_add);
                pstmt.executeUpdate();
                return "加入购物车成功!";
            } else {
                return "请勿重复购买!";
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return "";
    }

    /**
     * 获得购物车操作
     */
    public List<Integer> getShoppingCart(int user_id) {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        List<Integer> gameid = new ArrayList<>();
        String sql = "select * from shoppingcart where user_id='" + user_id + "'";
        try {
            // 查找购物车是否存在相应游戏
            pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                gameid.add(rs.getInt("game_id"));
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return gameid;
    }

    /**
     * 加入收藏操作
     */
    public String addCollection(int user_id, int game_id) {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        String sql = "select * from collection where user_id='" + user_id + "'and game_id='" + game_id + "'";
        String sql_add = "insert into collection values(" + user_id + "," + game_id + ")";
        try {
            // 查找收藏列表是否存在相应游戏
            pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            if (!rs.next()) {
                pstmt = conn.prepareStatement(sql_add);
                pstmt.executeUpdate();
                return "加入收藏成功!";
            } else {
                return "请勿重复收藏!";
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return "";
    }

    /**
     * 获得收藏操作
     */
    public List<Integer> getCollection(int user_id) {
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt = null;
        List<Integer> gameid = new ArrayList<>();
        String sql = "select * from collection where user_id='" + user_id + "'";
        try {
            // 查找收藏是否存在相应游戏
            pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                gameid.add(rs.getInt("game_id"));
            }
            System.out.println(gameid);
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return gameid;
    }
}
