package com.kingcool.yiqiyou;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class RegisterActivity extends AppCompatActivity {

    private EditText et_Username;
    private EditText et_Userpwd;
    private EditText et_ReUserpwd;
    private EditText et_Userphone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        et_Username = findViewById(R.id.et_username);
        et_Userpwd = findViewById(R.id.et_userpwd);
        et_ReUserpwd = findViewById(R.id.et_reuserpwd);
        et_Userphone = findViewById(R.id.et_userphone);
        //为注册按钮添加点击监听事件
        Button btnRegister = findViewById(R.id.btn_register);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //获取用户输入数据
                String name = et_Username.getText().toString();
                String pwd = et_Userpwd.getText().toString().trim();//去掉首位空格
                String repwd = et_ReUserpwd.getText().toString().trim();
                String phone = et_Userphone.getText().toString();
                //用户注册信息判空
                if(name == ""||name.length()<=5){
                    et_Username.requestFocus();
                    et_Username.setError("对不起，用户名不能小于6位!");
                }else if(pwd == ""||pwd.length()<=5) {
                    et_Userpwd.requestFocus();
                    et_Userpwd.setError("对不起，密码不能为空!");
                }else if(!repwd.equals(pwd)) {
                    et_ReUserpwd.requestFocus();
                    et_ReUserpwd.setError("对不起，两次密码不一致!");
                }else if(phone == ""||phone.length()!=11){
                    et_Userphone.requestFocus();
                    et_Userphone.setError("对不起，电话号必须为11位！");
                }else {
                    //都不为空时判断两次密码输入是否一致
                    //字符串类型判等pwd和repwd
                    if(!pwd.equals(repwd)){
                        et_ReUserpwd.requestFocus();
                        et_ReUserpwd.setError("两次输入的密码不一致！");
                    }else {
                        //两次输入密码一样
                        String path = "http://10.7.89.239:8080/YQY/RegisterServlet";//404教室
                        //调用LoginTask ，把获取到的用户名，密码和路径放入方法中
                        new RegisterTask().execute(name,pwd,phone,path);
                        //注册成功后跳转至用户登录界面
                        Intent intent = new Intent(RegisterActivity.this,LoginActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }
            }
        });
    }
    //注册异步任务
    public class RegisterTask extends AsyncTask {

        @Override
        protected Object doInBackground(Object[] objects) {
            //依次获取用户名，密码和路径
            String name = objects[0].toString();
            String pwd = objects[1].toString();
            String phone = objects[2].toString();
            String path = objects[3].toString();
            URL url= null;
            try {
                url = new URL(path+"?name="+name+"&pwd="+pwd+"&phone="+phone);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setRequestProperty("contentType","UTF-8");
                if(connection.getResponseCode()==200) {
                    InputStream is = connection.getInputStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    String str = br.readLine();
                    return str;
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
        @Override
        protected void onPostExecute(Object o){
            super.onPostExecute(o);
            String str = (String) o;
            Toast.makeText(RegisterActivity.this, str, Toast.LENGTH_SHORT).show();
        }
    }

}
