package com.kingcool.yiqiyou;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class ShopDetailActivity extends AppCompatActivity {
    private String user_id;
    private ImageButton ib_image;
    private TextView tv_name;
    private TextView tv_price;
    private TextView tv_introduction;
    private String imagePath;
    private Drawable drawable;
    private String imageString;
    private JSONObject jo;
    private int gameid;
    private ImageButton iBChange;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_detail);
        ib_image = findViewById(R.id.ib_image);
        tv_name = findViewById(R.id.tv_name);
        tv_price = findViewById(R.id.tv_price);
        tv_introduction = findViewById(R.id.tv_introduction);
        //图片id
        Intent intent = getIntent();
        String id = intent.getStringExtra("id");
        user_id = intent.getStringExtra("user_id");

        Log.e("sda",""+user_id);
        String path="http://10.7.89.239:8080/YQY/getGameDetailsServlet";
//        String path="http://192.168.0.101:8080/YQY/getGameDetailsServlet";
        new sdTask().execute(id,path);
        //购买游戏点击事件
        Button btn_buy = findViewById(R.id.btn_buy);
        btn_buy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new buyTask().execute();
            }
        });
        //下载游戏点击事件
        Button btn_download = findViewById(R.id.btn_download);
        btn_download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        //返回上一层
        LinearLayout linearLayout = findViewById(R.id.ll_back);
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        final ImageButton iBChange=findViewById(R.id.xinxing);
        iBChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (iBChange.isPressed()){
                    iBChange.setImageResource(R.drawable.xinxing1);
                    new myTask().execute();
                } else {
                    iBChange.setImageResource(R.drawable.xinxing);
                }
            }
        });
    }
    //收藏异步任务
    public class myTask extends AsyncTask {

        @Override
        protected Object doInBackground(Object[] objects) {

            try {
                String path2="http://10.7.89.239:8080/YQY/CollectionServlet";
//                String path2="http://192.168.0.101:8080/YQY/CollectionServlet";
                URL url = new URL(path2+"?user_id="+user_id+"&game_id="+gameid);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                int code = connection.getResponseCode();
                if(code==200){
                    InputStream is = connection.getInputStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    String s = br.readLine();
                    return s;
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            String s = (String)o;
            Toast.makeText(ShopDetailActivity.this,s , Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(ShopDetailActivity.this,com.kingcool.yiqiyou.siderbar_list.siderbar_myCollection.class);
            //传用户ID
            intent.putExtra("user_id", user_id);
            startActivity(intent);
            finish();
        }
    }
    //购买游戏异步任务
    public class buyTask extends AsyncTask {

        @Override
        protected Object doInBackground(Object[] objects) {
            try {
                String path1="http://10.7.89.239:8080/YQY/BuyGameServlet";
//                String path1="http://192.168.0.101:8080/YQY/BuyGameServlet";
                URL url = new URL(path1+"?user_id="+user_id+"&game_id="+gameid);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                int code = connection.getResponseCode();
                if(code==200){
                    InputStream is = connection.getInputStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    String s = br.readLine();
                    return s;
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            String s = (String)o;
            Toast.makeText(ShopDetailActivity.this,s , Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(ShopDetailActivity.this, ShoppingCartActivity.class);
            //传用户ID
            intent.putExtra("user_id", user_id);
            startActivity(intent);
            finish();
        }
    }


    //获得游戏详情异步任务
    public class sdTask extends AsyncTask {

        @Override
        protected Object doInBackground(Object[] objects) {
            String id = objects[0].toString();
            String path = objects[1].toString();
            try {
                URL url = new URL(path+"?id="+id);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                int code = connection.getResponseCode();
                if(code==200){
                    InputStream is = connection.getInputStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    String s = br.readLine();
                    jo = new JSONObject(s);
                    gameid = jo.getInt("game_id");
                    imageString = jo.getString("game_image");
                    imagePath = "http://10.7.89.239:8080/YQY/images/"+imageString;
//                    imagePath = "http://192.168.0.101:8080/YQY/images/"+imageString;
                    tv_name.setText(jo.getString("game_name"));
                    Log.e("test",""+tv_name.getText().toString());
                    tv_price.setText(jo.getString("game_price"));
                    tv_introduction.setText(jo.getString("game_introduction"));

                    //将保存在服务器的图片的URL转换成drawable
                    drawable = Drawable.createFromStream(
                            new URL(imagePath).openStream(), "1");
                    return drawable;
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            Drawable drawable = (Drawable)o;
            ib_image.setBackground(drawable);
        }
    }

}
