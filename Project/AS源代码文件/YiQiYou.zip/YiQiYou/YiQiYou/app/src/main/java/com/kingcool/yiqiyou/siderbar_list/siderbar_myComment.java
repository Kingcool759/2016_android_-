package com.kingcool.yiqiyou.siderbar_list;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import com.kingcool.yiqiyou.MainActivity;
import com.kingcool.yiqiyou.R;

public class siderbar_myComment extends AppCompatActivity {
    private String user_id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //获取MainActivity传过来的Intent
        Intent intent = getIntent();
        user_id = intent.getStringExtra("user_id");

        setContentView(R.layout.siderbar_my_comment);
        LinearLayout linearLayout = findViewById(R.id.mycomment_back);
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(siderbar_myComment.this, MainActivity.class);
                intent.putExtra("user_id",user_id);
                startActivity(intent);
                finish();
            }
        });
        Button btnGoToMain = findViewById(R.id.goto_main);
        btnGoToMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

}
