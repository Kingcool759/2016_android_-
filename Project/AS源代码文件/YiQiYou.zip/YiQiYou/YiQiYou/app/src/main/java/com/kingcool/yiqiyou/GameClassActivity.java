package com.kingcool.yiqiyou;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.sip.SipSession;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.kingcool.yiqiyou.Fragments.FriendsFragment;
import com.kingcool.yiqiyou.siderbar_list.siderbar_myInformation;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class GameClassActivity extends AppCompatActivity {
    private ListView listView;
    private List<String> namelist;
    private List<String> pricelist;
    private List<Drawable> imagelist;
    private List<String> pathlist;
    private List<Integer>idlist;
    private TextView tv1;
    private TextView tv2;
    private TextView tv3;
    private ImageView im1;
    private String classification;
    private String[] strings;
    private String user_id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_class);

        Intent intent = getIntent();
        user_id = intent.getStringExtra("user_id");
        classification = intent.getStringExtra("类别");

//        String path=" http://10.222.184.97:8080/YQY/GameClassifyServlet";
        String path="http://10.7.89.239:8080/YQY/GameClassifyServlet";
        new GameTask().execute(classification,path);

        listView=(ListView)findViewById(R.id.lv_game);
        LinearLayout linearLayout = findViewById(R.id.myinfo_back);
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    //自定义适配器
    class MyBaseAdapter extends BaseAdapter {


        public int getCount(){

            return  namelist.size();
        }

        public  Object getItem(int mposition){
            return  strings [mposition];
        }

        public long getItemId(int mposition) {
            return mposition;
        }

        //重写getView方法
        @Override
        public View getView(int position, View converView, ViewGroup parent){

            View view=getLayoutInflater().inflate(R.layout.game_list_item,null);
            tv1=(TextView)view.findViewById(R.id.Text1);
            tv2=(TextView)view.findViewById(R.id.Text2);
            tv3=(TextView)view.findViewById(R.id.Text3);
            im1=(ImageView)view.findViewById(R.id.image1);
            tv1.setText(namelist.get(position));
            tv2.setText(classification);
            tv3.setText(pricelist.get(position));

            im1.setBackground(imagelist.get(position));
            Log.e("getView",""+imagelist.get(position));
            return view;
        }
    }

    //异步任务
    public class GameTask extends AsyncTask {

        @Override
        protected Object doInBackground(Object[] objects) {

            String classification = objects[0].toString();
            String path = objects[1].toString();
            try {
                URL url = new URL(path+"?classification="+classification);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                int code = connection.getResponseCode();
                if(code==200){
                    InputStream is = connection.getInputStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    String s = br.readLine();
                    JSONArray ja = new JSONArray(s);
                    namelist = new ArrayList<>();
                    pricelist = new ArrayList<>();
                    imagelist = new ArrayList<>();
                    pathlist = new ArrayList<>();
                    idlist = new ArrayList<>();
                    for(int i=0;i<ja.length();i++){
//                        String imagePath = "http://10.222.184.97:8080/YQY/images/"+ja.getJSONObject(i).getString("game_image");
                        String imagePath = "http://10.7.89.239:8080/YQY/images/"+ja.getJSONObject(i).getString("game_image");
                        namelist.add(ja.getJSONObject(i).getString("game_name"));
                        pricelist.add(ja.getJSONObject(i).getString("game_price"));
                        pathlist.add(imagePath);
                        idlist.add(ja.getJSONObject(i).getInt("game_id"));
                    }
                    for(int i=0;i<pathlist.size();i++){
                        imagelist.add(Drawable.createFromStream(
                                new URL(pathlist.get(i)).openStream(), "1"));
                    }
                    //重写getItem()使用
                    strings = new String[namelist.size()];
                    namelist.toArray(strings);
                    listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            Intent intent = new Intent(GameClassActivity.this,ShopDetailActivity.class);
                            intent.putExtra("id",String.valueOf(idlist.get(position)));
                            intent.putExtra("user_id",user_id);
                            startActivity(intent);
                        }
                    });
                    return s;
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            listView.setAdapter(new MyBaseAdapter());
        }
    }
}
