package com.kingcool.yiqiyou;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.kingcool.yiqiyou.Fragments.ForumFragment;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class LoginActivity extends AppCompatActivity {
    private EditText et_name;
    private EditText et_password;
    private ToggleButton tb_smalleye;
    private Button btnLogin;
    private Button btnGotoRegister;
    private Button btnForgetPwd;
    private CheckBox cb_remember;
    private SharedPreferences sp;
    private SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        //记住密码功能实现
        et_name = (EditText) findViewById(R.id.et_name);
        et_password = (EditText) findViewById(R.id.et_password);
        //完成sp的初始化
        sp = getSharedPreferences("config",MODE_PRIVATE);
        cb_remember = (CheckBox) findViewById(R.id.cb_remember);
        //获取sp里面存储的数据
        boolean isRemember = sp.getBoolean("记住密码",false);
        if(isRemember) {
            String name = sp.getString("name", "");
            String pwd = sp.getString("pwd", "");
            et_name.setText(name);
            et_password.setText(pwd);
            cb_remember.setChecked(true);//第一次记住密码此后默认选中
        }
        btnLogin = (Button) findViewById(R.id.btn_login);
        btnGotoRegister = (Button) findViewById(R.id.btn_goto_register);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //验证用户输入用户名和密码是否符合规则
                String name = et_name.getText().toString();
                String pwd = et_password.getText().toString();
                if (name.equals("") || name.length() <= 5) {
                    et_name.requestFocus();
                    et_name.setError("对不起，用户名不能小于6位!");
                } else if (pwd.equals("") || pwd.length() <= 5) {
                    et_password.requestFocus();
                    et_password.setError("对不起，密码不能小于6位!");
                } else {
                    //获取到一个参数文件编辑器
                    editor = sp.edit();
                    //记住密码
                    if(cb_remember.isChecked()){
                        editor.putBoolean("记住密码",true);
                        editor.putString("name",name);
                        editor.putString("pwd",pwd);
                        //把数据存入sp磁盘中
                        editor.commit();
                    }else{
                        editor.clear();
                    }
                    //经由内存异步存在磁盘中
                    editor.apply();
                    //连接服务器进行数据库用户信息数据验证
                    //服务器地址
                    String path = "http://10.7.89.239:8080/YQY/LoginServlet";//404教室
//                    String path = "http://192.168.0.101:8080/YQY/LoginServlet";//宿舍
                    //调用LoginTask ，把获取到的用户名，密码和路径放入方法中
                    //调用onPostExecute方法，进行用户登录的验证页面跳转
                    new LoginTask().execute(name,pwd,path);
                }
            }
        });
        //密码小眼睛功能(明密文切换)
        tb_smalleye =(ToggleButton) findViewById(R.id.tb_smalleye);
        tb_smalleye.setOnCheckedChangeListener(new ToggleButtonClick());//创建类对象
        //从登录界面activity跳转到新用户注册界面RegisterActivity(此处无需改动)
        btnGotoRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this,RegisterActivity.class);
                startActivity(intent);
            }
        });

        //忘记密码
        btnForgetPwd = findViewById(R.id.btn_forgetpwd);
        btnForgetPwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this,ForgetPwdActivity.class);
                startActivity(intent);
            }
        });
    }
    //小眼睛的监听器
    //密码可见性按钮监听
    private class ToggleButtonClick implements CompoundButton.OnCheckedChangeListener{

        @Override
        public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
            //判断事件源的选中状态
            if (isChecked){
                //显示密码
                et_password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            }else {
                // 隐藏密码
                et_password.setTransformationMethod(PasswordTransformationMethod.getInstance());
            }
            //每次显示或者关闭时，密码显示编辑的线不统一在最后，下面是为了统一
            et_password.setSelection(et_password.length());
        }
    }
    //异步任务
    public class LoginTask extends AsyncTask {

        @Override
        protected Object doInBackground(Object[] objects) {
            //依次获取用户名，密码和路径
            String name = objects[0].toString();
            String pwd = objects[1].toString();
            String path = objects[2].toString();
            URL url= null;
            try {
                url = new URL(path+"?name="+name+"&pwd="+pwd);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setRequestProperty("contentType","UTF-8");
                if(connection.getResponseCode()==200) {
                    InputStream is = connection.getInputStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    String str = br.readLine();
                    JSONObject jo = new JSONObject(str);
                    return jo;
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
        @Override
        //在doInBackground方法执行结束后再运行，并且运行在UI线程当中
        //主要用于将异步操作任务执行的结果展示给用户
        protected void onPostExecute(Object o){
            super.onPostExecute(o);
            JSONObject jo  = (JSONObject) o;
            String s = null;
            int id = 0;
            try {
                s = jo.getString("result");
                id = jo.getInt("user_id");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            if(s.equals("登录成功！正在跳转......")){
                Toast.makeText(LoginActivity.this,s , Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                //传用户ID
                intent.putExtra("user_id",String.valueOf(id));
                startActivity(intent);

                finish();
            }else{
                Toast.makeText(LoginActivity.this, s, Toast.LENGTH_SHORT).show();
            }
        }
    }
}
