package com.kingcool.yiqiyou.siderbar_list;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.kingcool.yiqiyou.R;

public class ChangeMyImage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_my_image);
    }
}
