package com.kingcool.yiqiyou;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class RePwdActivity extends AppCompatActivity {
    private EditText etNewpwd;
    private EditText etReNewpwd;
    private Button btnSubmit2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_re_pwd);

        etNewpwd = findViewById(R.id.et_newpwd);
        etReNewpwd = findViewById(R.id.et_renewpwd);
        btnSubmit2 = findViewById(R.id.btn_submit2);
        //获取从forgetpwd来的rename数据
        Intent intent = getIntent();
        final String rename = intent.getStringExtra("rename");
        Log.e("intent-rename",""+rename);
        btnSubmit2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newpwd = etNewpwd.getText().toString().trim();
                String renewpwd = etReNewpwd.getText().toString().trim();
                if(!newpwd.equals(renewpwd)){
                    Toast toast=Toast.makeText(getApplicationContext(),"两次密码不一致，请重新输入",Toast.LENGTH_LONG);
                    toast.show();
                    //清空edit
                    etNewpwd.setText("");
                    etReNewpwd.setText("");
                }else{
                    //开启异步任务：重置密码
                    String path = "http://10.7.89.239:8080/YQY/RepwdServlet2";//404教室
                    new ReplacePWD().execute(rename,newpwd,path);
                }
            }
        });
    }
    private class ReplacePWD extends AsyncTask{
        @Override
        protected Object doInBackground(Object[] objects) {
            //依次获取用户名，密码和路径
            String rename = objects[0].toString();
            String newpwd = objects[1].toString();
            String path = objects[2].toString();
            URL url= null;
            try {
                url = new URL(path+"?rename="+rename+"&newpwd="+newpwd);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setRequestProperty("contentType","UTF-8");
                if(connection.getResponseCode()==200) {
                    InputStream is = connection.getInputStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    String str = br.readLine();
                    return str;
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            String str = (String) o;
            if("密码重置成功！".equals(str)){
                Toast.makeText(RePwdActivity.this,str,Toast.LENGTH_LONG).show();
                Intent go_login = new Intent(RePwdActivity.this,LoginActivity.class);
                startActivity(go_login);

            }
        }
    }
}
