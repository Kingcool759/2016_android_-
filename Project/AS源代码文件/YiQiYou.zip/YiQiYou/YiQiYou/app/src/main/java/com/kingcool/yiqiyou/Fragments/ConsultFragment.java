package com.kingcool.yiqiyou.Fragments;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.kingcool.yiqiyou.ConsultDetails;
import com.kingcool.yiqiyou.ConsultSearch;
import com.kingcool.yiqiyou.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class ConsultFragment extends Fragment {
    private Button BtnSearch;
    private ListView listView;
    private ImageView imageView;
    private TextView textView;
    private List<Drawable> imagelist;
    private List<String> titlelist;
    private List<String> pathlist;
    private List<Integer>idlist;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.consult_fragment_layout,container,false);
        //顶部搜索栏
        BtnSearch =(Button) view.findViewById(R.id.btn_search_zixun);
        BtnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), ConsultSearch.class);
                startActivity(intent);
            }
        });
        listView = (ListView) view.findViewById(R.id.listView_consult);
        //执行异步任务
        new GetConsult().execute();
        return view;
    }
    class ListViewAdapter extends BaseAdapter{
        @Override
        public int getCount() {
            return titlelist.size();
        }

        @Override
        public long getItemId(int mposition) {
            return mposition;
        }

        @Override
        public Object getItem(int mposition) {
            return titlelist.get(mposition);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            //加载布局为一个视图
            View view = getLayoutInflater().inflate(R.layout.consult_listview_item,null);
            //获取控件id
            imageView = (ImageView) view.findViewById(R.id.iv_consult);
            textView = (TextView) view.findViewById(R.id.tv_consult);
            textView.setText(titlelist.get(position));
            imageView.setBackground(imagelist.get(position));
            return view;
        }
    }
    //异步任务
    class GetConsult extends AsyncTask{
        @Override
        protected Object doInBackground(Object[] objects) {
            try {
                URL url = new URL("http://10.7.89.239:8080/YQY/GetConsultServlet");
//                URL url = new URL("http://192.168.0.101:8080/YQY/GetConsultServlet");
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                int code = connection.getResponseCode();
                if(code==200){
                    InputStream is = connection.getInputStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    String s = br.readLine();
                    //解析JSON数据
                    JSONArray ja = new JSONArray(s);
                    idlist = new ArrayList<>();
                    imagelist = new ArrayList<>();
                    titlelist = new ArrayList<>();
                    pathlist = new ArrayList<>();
                    Log.e("gft",""+ja.length());
                    for(int i=0;i<ja.length();i++){
                        String imagePath = "http://10.7.89.239:8080/YQY/images/"+ja.getJSONObject(i).getString("consult_icon");
//                        String imagePath = "http://192.168.0.101:8080/YQY/images/"+ja.getJSONObject(i).getString("consult_icon");
//                        Log.e("ip",""+imagePath);
                        idlist.add(ja.getJSONObject(i).getInt("consult_id"));
                        titlelist.add(ja.getJSONObject(i).getString("consult_title"));
                        pathlist.add(imagePath);
                    }
                    Log.e("gt",""+pathlist.size());
                    for(int j=0;j<pathlist.size();j++){
                        imagelist.add(Drawable.createFromStream(new URL(pathlist.get(j)).openStream(), "1"));
                    }
//                    Log.e("gdfdft",""+pathlist.size());
                }
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            //点击一个listview的item组件将id传递给ConsultDetails
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Intent intent10 = new Intent(getActivity(),ConsultDetails.class);
                    intent10.putExtra("id",String.valueOf(idlist.get(position)));
                    startActivity(intent10);
                }
            });
            listView.setAdapter(new ListViewAdapter());
        }
    }
}

