package com.kingcool.yiqiyou.Fragments;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.kingcool.yiqiyou.ChatActivity;
import com.kingcool.yiqiyou.CircleImageView;
import com.kingcool.yiqiyou.R;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class FriendsFragment extends Fragment {
    private ListView friendslistView;
    private List<Integer>idlist;
    private List<Drawable> imagelist;
    private List<String> namelist;
    private List<String> timelist;
    private List<String> pathlist;
    private ImageView iVaddfriends;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.friends_fragment_layout, container, false);
        //获取组件id
        friendslistView =(ListView) view.findViewById(R.id.friends_lv);
//        iVaddfriends=(ImageView) view.findViewById(R.id.addfriends);
        //动态点击添加好友
//        iVaddfriends.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//            }
//        });
        //开启获取好友列表异步任务
        new GetFriendsList().execute();
        return view;
    }
    class ListViewAdapter extends BaseAdapter{
        @Override
        public int getCount() {
            return namelist.size();
        }

        @Override
        public Object getItem(int position) {
            return namelist.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            //加载布局为一个视图
            View view = getLayoutInflater().inflate(R.layout.friends_fragment_list_item,null);
            CircleImageView imageView = (CircleImageView) view.findViewById(R.id.iv_friends_image);
            TextView text1 = (TextView) view.findViewById(R.id.tv_friends_name);
            TextView text2 = (TextView) view.findViewById(R.id.tv_chat_time);
            text1.setText(namelist.get(position));
            text2.setText(timelist.get(position));
            imageView.setImageDrawable(imagelist.get(position));
//            imageView.setBackground(imagelist.get(position));
            return view;
        }
    }
    class GetFriendsList extends AsyncTask{
        @Override
        protected Object doInBackground(Object[] objects) {
            URL url = null;
            try {
                url = new URL("http://10.7.89.239:8080/YQY/GetFriendsListServlet");
//                URL url = new URL("http://192.168.0.101:8080/YQY/GetFriendsListServlet");
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                int code = connection.getResponseCode();
                if (code == 200) {
                    InputStream is = connection.getInputStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    String s = br.readLine();
                    //解析JSON数据
                    JSONArray ja = new JSONArray(s);
                    idlist = new ArrayList<>();
                    imagelist = new ArrayList<>();
                    namelist = new ArrayList<>();
                    timelist = new ArrayList<>();
                    pathlist = new ArrayList<>();
                    for(int i=0;i<ja.length();i++){
                        String imagePath = "http://10.7.89.239:8080/YQY/images/"+ja.getJSONObject(i).getString("friends_image");
//                        String imagePath = "http://192.168.0.101:8080/YQY/images/"+ja.getJSONObject(i).getString("friends_image");
//                        Log.e("ip",""+imagePath);
                        idlist.add(ja.getJSONObject(i).getInt("friends_id"));
                        namelist.add(ja.getJSONObject(i).getString("friends_name"));
                        timelist.add(ja.getJSONObject(i).getString("chat_time"));
                        pathlist.add(imagePath);
                    }
                    Log.e("idlist",""+idlist);
                    Log.e("namelist",""+namelist);
                    Log.e("timelist",""+timelist);
                    Log.e("fl",""+pathlist.size());
                    for(int j=0;j<pathlist.size();j++){
                        imagelist.add(Drawable.createFromStream(new URL(pathlist.get(j)).openStream(), "1"));
                    }
                    Log.e("imagelist",""+imagelist);
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            //点击一个listview的item组件将id传递给ChatActivity
            friendslistView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Intent intent2 = new Intent(getActivity(),ChatActivity.class);
                    intent2.putExtra("id",String.valueOf(idlist.get(position)));
                    startActivity(intent2);
                }
            });
            friendslistView.setAdapter(new ListViewAdapter());
        }
    }
}
