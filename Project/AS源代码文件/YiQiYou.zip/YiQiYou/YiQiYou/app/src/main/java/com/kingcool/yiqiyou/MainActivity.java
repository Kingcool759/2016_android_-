package com.kingcool.yiqiyou;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentTabHost;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TextView;

import com.kingcool.yiqiyou.CircleImageView;

import com.kingcool.yiqiyou.Fragments.ConsultFragment;
import com.kingcool.yiqiyou.Fragments.ForumFragment;
import com.kingcool.yiqiyou.Fragments.FriendsFragment;
import com.kingcool.yiqiyou.Fragments.ShopFragment;
import com.kingcool.yiqiyou.siderbar_list.siderbar_myCollection;
import com.kingcool.yiqiyou.siderbar_list.siderbar_myComment;
import com.kingcool.yiqiyou.siderbar_list.siderbar_myInformation;
import com.kingcool.yiqiyou.siderbar_list.siderbar_myOrder;
import com.kingcool.yiqiyou.siderbar_list.siderbar_myRepertory;
import com.kingcool.yiqiyou.siderbar_list.siderbar_set;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private Map<String, View> tabspecViews = new HashMap<>();
    private Map<String, ImageView> imageViewMap = new HashMap<>();
    private ViewPager mViewPager;
    private String user_id;
    private String nickname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //获取LoginServlet传过来的Intent
        final Intent intent = getIntent();
        user_id = intent.getStringExtra("user_id");

//        //传用户名给ForumFragment
//        Intent intent1 = new Intent(MainActivity.this,ForumFragment.class);
//        intent1.putExtra("user_name",user_name);
//        startActivity(intent1);
        //软键盘顶起底部导航栏解决方法：
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        setContentView(R.layout.activity_main);

        //----侧边栏siderbar-------------------------------
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        //--------------------------------
//        //修改用户当前头像
//        View view = getLayoutInflater().inflate(R.layout.nav_header_main,null);
//        com.kingcool.yiqiyou.CircleImageView myimage = view.findViewById(R.id.myimage);
//        myimage.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Log.e("123","123");
//            }
//        });

        //获取FragmentTabHost对象
        FragmentTabHost fragmentTabHost = findViewById(android.R.id.tabhost);
        //初始化FragmentTabHost对象
        fragmentTabHost.setup(this,
                getSupportFragmentManager(),
                android.R.id.tabhost);

        //创建选项卡对象并添加选项卡
        TabHost.TabSpec tabSpec0 = fragmentTabHost.newTabSpec("tab0")
                .setIndicator(getTabSpecView("资讯",R.drawable.zixun, "tab0"));
        fragmentTabHost.addTab(tabSpec0, ConsultFragment.class, null);

        //创建选项卡对象并添加选项卡
        TabHost.TabSpec tabSpec1 = fragmentTabHost.newTabSpec("tab1")
                .setIndicator(getTabSpecView("好友",R.drawable.friends, "tab1"));
        fragmentTabHost.addTab(tabSpec1, FriendsFragment.class, null);

        //创建选项卡对象并添加选项卡
        TabHost.TabSpec tabSpec2 = fragmentTabHost.newTabSpec("tab2")
                .setIndicator(getTabSpecView("商城",R.drawable.shop, "tab2"));
        fragmentTabHost.addTab(tabSpec2, ShopFragment.class, null);
        //创建选项卡对象并添加选项卡
        TabHost.TabSpec tabSpec3 = fragmentTabHost.newTabSpec("tab3")
                .setIndicator(getTabSpecView("论坛",R.drawable.forum,"tab3"));
        fragmentTabHost.addTab(tabSpec3, ForumFragment.class, null);

        //设置默认选中某个选项卡
        fragmentTabHost.setCurrentTab(0);
        ImageView imageView1 = imageViewMap.get("tab0");
        imageView1.setImageResource(R.drawable.zixun_selected);

        //监听选项卡点击事件
        fragmentTabHost.setOnTabChangedListener(new TabHost.OnTabChangeListener() {
            @Override
            public void onTabChanged(String tabId) {
                Log.e("点击了选项卡",tabId);
                Set<String> keys = tabspecViews.keySet();
                for (String str : keys){
                    View view = tabspecViews.get(str);
                    ImageView imageView0 = imageViewMap.get("tab0");
                    ImageView imageView1 = imageViewMap.get("tab1");
                    ImageView imageView2 = imageViewMap.get("tab2");
                    ImageView imageView3 = imageViewMap.get("tab3");

                    //改变选项卡中的图片
                    if (tabId.equals("tab0")){
                        imageView0.setImageResource(R.drawable.zixun_selected);
                        imageView1.setImageResource(R.drawable.friends);
                        imageView2.setImageResource(R.drawable.shop);
                        imageView3.setImageResource(R.drawable.forum);
                    }else if(tabId.equals("tab1")){
                        imageView0.setImageResource(R.drawable.zixun);
                        imageView1.setImageResource(R.drawable.friends_selected);
                        imageView2.setImageResource(R.drawable.shop);
                        imageView3.setImageResource(R.drawable.forum);
                    }else if(tabId.equals("tab2")){
                        imageView0.setImageResource(R.drawable.zixun);
                        imageView1.setImageResource(R.drawable.friends);
                        imageView2.setImageResource(R.drawable.shop_selected);
                        imageView3.setImageResource(R.drawable.forum);
                    }else if(tabId.equals("tab3")){
                        imageView0.setImageResource(R.drawable.zixun);
                        imageView1.setImageResource(R.drawable.friends);
                        imageView2.setImageResource(R.drawable.shop);
                        imageView3.setImageResource(R.drawable.forum_selected);
                    }
                }
            }
        });
    }
    private View getTabSpecView(String name, int imageId, String tag){
        LayoutInflater layoutInflater = getLayoutInflater();
        View view = layoutInflater.inflate(R.layout.tabspc_layout,null);
        ImageView imageView = view.findViewById(R.id.image);
        imageView.setImageResource(imageId);
        TextView textView = view.findViewById(R.id.textView);
        textView.setText(name);
        tabspecViews.put(tag, view);
        imageViewMap.put(tag, imageView);
        return view;
    }


    //----------侧边栏-----------------------------------
    //返回键触发调用的方法
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        new gnTask().execute();
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    //----@Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_my) {
            Intent intent = new Intent(MainActivity.this,siderbar_myInformation.class);
            intent.putExtra("user_id",user_id);
            startActivity(intent);
        } else if (id == R.id.nav_repertory) {
            Intent intent = new Intent(MainActivity.this,siderbar_myRepertory.class);
            intent.putExtra("user_id",user_id);
            startActivity(intent);
        } else if (id == R.id.nav_order) {
            Intent intent = new Intent(MainActivity.this,siderbar_myOrder.class);
            intent.putExtra("user_id",user_id);
            startActivity(intent);
        } else if (id == R.id.nav_comment) {
            Intent intent = new Intent(MainActivity.this,siderbar_myComment.class);
            intent.putExtra("user_id",user_id);
            startActivity(intent);
        } else if (id == R.id.nav_collection) {
            Intent intent = new Intent(MainActivity.this,siderbar_myCollection.class);
            intent.putExtra("user_id",user_id);
            startActivity(intent);
        } else if (id == R.id.nav_set) {
            Intent intent = new Intent(MainActivity.this,siderbar_set.class);
            intent.putExtra("user_id",user_id);
            startActivity(intent);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    //获得昵称
    public class gnTask extends AsyncTask {
        @Override
        protected Object doInBackground(Object[] objects) {
            String path="http://10.7.89.239:8080/YQY/GetNickNameServlet";
            try {
                URL url = new URL(path+"?user_id="+user_id);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                int code = connection.getResponseCode();
                if(code==200){
                    InputStream is = connection.getInputStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    String s = br.readLine();
                    return s;
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            nickname = (String)o;
            //侧边栏用户昵称
            TextView login_user = findViewById(R.id.login_user);
            login_user.setText(nickname);
        }
    }
}
