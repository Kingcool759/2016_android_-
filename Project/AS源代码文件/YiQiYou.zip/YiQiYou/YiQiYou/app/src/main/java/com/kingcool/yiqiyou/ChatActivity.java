package com.kingcool.yiqiyou;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

public class ChatActivity extends AppCompatActivity {
    ArrayList<HashMap<String, Object>> chatList = null;
    String[] from = {"image", "text"};
    int[] to = {R.id.chatlist_image_me, R.id.chatlist_text_me, R.id.chatlist_image_other, R.id.chatlist_text_other};
    int[] layout = {R.layout.chat_own, R.layout.chat_another};
    String userQQ = null;
    /**
     * 这里两个布局文件使用了同一个id，测试一下是否管用
     * TT事实证明这回产生id的匹配异常！所以还是要分开。。
     * <p>
     * userQQ用于接收Intent传递的qq号，进而用来调用数据库中的相关的联系人信息，这里先不讲
     * 先暂时使用一个头像
     */

    public final static int OTHER = 1;
    public final static int ME = 0;


    protected ListView chatListView = null;
    protected Button chatSendButton = null;
    protected EditText editText = null;

    protected MyChatAdapter adapter = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_chat);
        chatList = new ArrayList<HashMap<String, Object>>();
        addTextToList("好久不见啊，最近在玩什么游戏？", ME);
        addTextToList("就商城里刚出的那个\n  ^_^", OTHER);
        addTextToList("玩着怎么样啊，我还没下", ME);
        addTextToList("好玩，我极力推荐你下个，一起玩啊！", OTHER);
        chatSendButton = (Button) findViewById(R.id.chat_bottom_sendbutton);
        editText = (EditText) findViewById(R.id.chat_bottom_edittext);
        chatListView = (ListView) findViewById(R.id.chat_list);

        //顶部返回键主界面跳转
        LinearLayout linearLayout = findViewById(R.id.back_friends);
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        adapter = new MyChatAdapter(ChatActivity.this, chatList, layout, from, to);


        chatSendButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                String myWord = null;
                /**
                 * 这是一个发送消息的监听器，注意如果文本框中没有内容，那么getText()的返回值可能为
                 * null，这时调用toString()会有异常！所以这里必须在后面加上一个""隐式转换成String实例
                 * ，并且不能发送空消息。
                 */
                myWord = (editText.getText() + "").toString();
                if (myWord.length() == 0)
                    return;
                editText.setText("");
                addTextToList(myWord, ME);
                /**
                 * 更新数据列表，并且通过setSelection方法使ListView始终滚动在最底端
                 */
                adapter.notifyDataSetChanged();
                chatListView.setSelection(chatList.size() - 1);
            }
        });
        //获取好友列表点击item传过来的好友id
        Intent intent1 = getIntent();
        String friend_id = intent1.getStringExtra("id");
        Log.e("chat",""+intent1);
//        //开启异步任务获取好友头像
//        String path = "http://10.7.89.239:8080/YQY/GetFriendsImage";
//        new GetFriendsImage().execute(path,friend_id);
        chatListView.setAdapter(adapter);
    }
    protected void addTextToList(String text, int who) {
        HashMap<String, Object> map = new HashMap<String, Object>();
        map.put("person", who);
        map.put("image", who == ME ? R.drawable.a : R.drawable.a);
        map.put("text", text);
        chatList.add(map);
    }
    private class MyChatAdapter extends BaseAdapter {

        Context context = null;
        ArrayList<HashMap<String, Object>> chatList = null;
        int[] layout;
        String[] from;
        int[] to;
        //构造方法
        public MyChatAdapter(Context context,
                             ArrayList<HashMap<String, Object>> chatList, int[] layout, String[] from, int[] to) {
            super();
            this.context = context;
            this.chatList = chatList;
            this.layout = layout;
            this.from = from;
            this.to = to;
        }
        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            return chatList.size();
        }
        @Override
        public Object getItem(int arg0) {
            // TODO Auto-generated method stub
            return null;
        }
        @Override
        public long getItemId(int position) {
            // TODO Auto-generated method stub
            return position;
        }
        class ViewHolder {
            public ImageView imageView = null;
            public TextView textView = null;

        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // TODO Auto-generated method stub
            ViewHolder holder = null;
            int who = (Integer) chatList.get(position).get("person");
            convertView = LayoutInflater.from(context).inflate(
                    layout[who == ME ? 0 : 1], null);
            holder = new ViewHolder();
            holder.imageView = (ImageView) convertView.findViewById(to[who * 2 + 0]);
            holder.textView = (TextView) convertView.findViewById(to[who * 2 + 1]);
            System.out.println(holder);
            System.out.println("WHYWHYWHYWHYW");
            System.out.println(holder.imageView);
            holder.imageView.setBackgroundResource((Integer) chatList.get(position).get(from[0]));
//            holder.imageView.setImageResource();
            holder.textView.setText(chatList.get(position).get(from[1]).toString());
            return convertView;
        }
    }
//    class GetFriendsImage extends AsyncTask{
//        @Override
//        protected Object doInBackground(Object[] objects) {
//            String path = objects[0].toString();
//            String friend_id = objects[1].toString();
//            URL url = null;
//            try {
//                url = new URL(path+"?friend_id="+friend_id);
//                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
//                connection.setRequestMethod("GET");
//                connection.setConnectTimeout(5000);
//                int code = connection.getResponseCode();
//                if (code == 200) {
//                    InputStream is = connection.getInputStream();
//                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
//                    String s = br.readLine();
//                    JSONObject jo = new JSONObject(s);
//                    return jo;
//                }
//            } catch (ProtocolException e) {
//                e.printStackTrace();
//            } catch (MalformedURLException e) {
//                e.printStackTrace();
//            } catch (IOException e) {
//                e.printStackTrace();
//            } catch (JSONException e) {
//                e.printStackTrace();
//            }
//            return null;
//        }
//
//        @Override
//        protected void onPostExecute(Object o) {
//            super.onPostExecute(o);
//        }
//    }
}
