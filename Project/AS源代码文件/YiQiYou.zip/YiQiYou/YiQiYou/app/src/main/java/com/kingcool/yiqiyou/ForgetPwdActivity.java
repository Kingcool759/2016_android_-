package com.kingcool.yiqiyou;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.Timer;
import java.util.TimerTask;

public class ForgetPwdActivity extends AppCompatActivity {
    private EditText etRename;
    private EditText etRephone;
    private Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_pwd);
        etRename = findViewById(R.id.et_rename);
        etRephone = findViewById(R.id.et_rephone);
        btnSubmit = findViewById(R.id.btn_submit);
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String rename = etRename.getText().toString();
                String rephone = etRephone.getText().toString();
                if (rename.equals("") || rename.length() <= 5) {
                    etRename.requestFocus();
                    etRename.setError("对不起，用户名不能小于6位!");
                } else if (rephone.equals("") || rephone.length() != 11) {
                    etRephone.requestFocus();
                    etRephone.setError("对不起，电话号码格式错误！");
                } else {
                    //异步任务
                    String path = "http://10.7.89.239:8080/YQY/RepwdServlet";//404教室
//                String path = "http://192.168.0.101:8080/YQY/LoginServlet";//宿舍
                    new QueryPhone().execute(rename, rephone, path);
                }
            }
        });
    }
    private class QueryPhone extends AsyncTask{
        @Override
        protected Object doInBackground(Object[] objects) {
            //依次获取用户名，手机号和路径
            String rename = objects[0].toString();
            String rephone = objects[1].toString();
            String path = objects[2].toString();
            URL url = null;
            try {
                url = new URL(path+"?rename="+rename+"&rephone="+rephone);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setRequestProperty("contentType","UTF-8");
                if(connection.getResponseCode()==200) {
                    InputStream is = connection.getInputStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    String str = br.readLine();
                    return str;
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            //对后台获取数据流进行处理
            String str = (String) o;
            if(str.equals("用户名与绑定手机号匹配！")){
                //跳转到重置密码界面
                Toast.makeText(ForgetPwdActivity.this, str, Toast.LENGTH_SHORT).show();
                final Intent intent = new Intent(ForgetPwdActivity.this,RePwdActivity.class);
                //向repwd传递rename 数据
                String rename = etRename.getText().toString();
                intent.putExtra("rename",rename);
                //延时1.5秒跳转
                Timer timer = new Timer();
                TimerTask timerTask = new TimerTask() {
                    @Override
                    public void run() {
                        startActivity(intent);
                    }
                };
                timer.schedule(timerTask,1500);
            }else {
                Toast.makeText(ForgetPwdActivity.this, str, Toast.LENGTH_SHORT).show();
            }
        }
    }
}
