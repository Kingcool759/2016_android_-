package com.kingcool.yiqiyou.siderbar_list;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;

import com.kingcool.yiqiyou.GameClassActivity;
import com.kingcool.yiqiyou.MainActivity;
import com.kingcool.yiqiyou.R;
import com.kingcool.yiqiyou.ShopDetailActivity;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class siderbar_myRepertory extends AppCompatActivity {
    private String user_id;
    private List<String> namelist;
    private List<Drawable> imagelist;
    private List<String> pathlist;
    private List<String> classificationlist;
    private ListView listView;
    private String path;
    private MyBaseAdapter myBaseAdapter;
    //切换图片用
    boolean isChanged = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.siderbar_my_repertory);

        path="http://10.7.89.239:8080/YQY/GetRepertoryServlet";
        myBaseAdapter = new MyBaseAdapter();

        Intent intent = getIntent();
        user_id = intent.getStringExtra("user_id");

        LinearLayout linearLayout = findViewById(R.id.myrepertory_back);
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(siderbar_myRepertory.this, MainActivity.class);
                intent.putExtra("user_id",user_id);
                startActivity(intent);
                finish();
            }
        });
        //popupmenu
        final ImageView iv_select = findViewById(R.id.iv_select);
        iv_select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popupMenu = new PopupMenu(getApplicationContext(),iv_select);
                popupMenu.getMenuInflater().inflate(R.menu.popup_menu,popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        new gameTask().execute(item.getTitle(),path);
                        return false;
                    }
                });
                popupMenu.show();
            }
        });

        //ListView
        listView = findViewById(R.id.lv_game);
        new gameTask().execute("全部",path);
    }

    //自定义适配器
    class MyBaseAdapter extends BaseAdapter {

        public int getCount(){

            return  namelist.size();
        }

        public  Object getItem(int mposition){
            return  namelist.get(mposition);
        }

        public long getItemId(int mposition) {
            return mposition;
        }

        //重写getView方法
        @Override
        public View getView(int position,View converView,ViewGroup parent){
            View view=getLayoutInflater().inflate(R.layout.myrepertory_list_item,null);
            TextView tv1=(TextView)view.findViewById(R.id.Text1);
            TextView tv2=(TextView)view.findViewById(R.id.Text2);
            ImageView im1=(ImageView)view.findViewById(R.id.image1);
            tv1.setText(namelist.get(position));
            tv2.setText(classificationlist.get(position));
            im1.setBackground(imagelist.get(position));
            return view;
        }
    }


    public class gameTask extends AsyncTask{

        @Override
        protected Object doInBackground(Object[] objects) {
            String classification = objects[0].toString();
            String path = objects[1].toString();
            try {
                URL url = new URL(path+"?user_id="+user_id+"&classification="+classification);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                int code = connection.getResponseCode();
                if(code==200){
                    InputStream is = connection.getInputStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    String s = br.readLine();
                    JSONArray ja = new JSONArray(s);
                    namelist = new ArrayList<>();
                    imagelist = new ArrayList<>();
                    pathlist = new ArrayList<>();
                    classificationlist = new ArrayList<>();
                    for(int i=0;i<ja.length();i++){
//                        String imagePath = "http://10.222.184.97:8080/YQY/images/"+ja.getJSONObject(i).getString("game_image");
                        String imagePath = "http://10.7.89.239:8080/YQY/images/"+ja.getJSONObject(i).getString("game_image");
                        namelist.add(ja.getJSONObject(i).getString("game_name"));
                        classificationlist.add(ja.getJSONObject(i).getString("game_classification"));
                        pathlist.add(imagePath);
                    }
                    for(int i=0;i<pathlist.size();i++){
                        imagelist.add(Drawable.createFromStream(
                                new URL(pathlist.get(i)).openStream(), "1"));
                    }
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            listView.setAdapter(myBaseAdapter);

        }
    }
}
