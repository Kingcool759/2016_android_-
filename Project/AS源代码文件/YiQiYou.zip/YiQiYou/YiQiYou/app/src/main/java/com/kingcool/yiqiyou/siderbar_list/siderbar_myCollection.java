package com.kingcool.yiqiyou.siderbar_list;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.kingcool.yiqiyou.R;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class siderbar_myCollection extends AppCompatActivity {

        private ListView listView;
        private String user_id;
        private List<String> namelist;
        private List<String> pricelist;
        private List<Drawable> imagelist;
        private List<String> pathlist;
        private String[] strings;
        private List<Integer> gameidlist;


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.siderbar_my_collection);


            Intent intent = getIntent();
            user_id = intent.getStringExtra("user_id");

            new getCollectionTask().execute();
            LinearLayout mycollection_back = findViewById(R.id.mycollection_back);
            mycollection_back.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            });
            //ListView
            listView = (ListView)findViewById(R.id.lv_collection);

        }

        //自定义适配器
        class MyBaseAdapter extends BaseAdapter {

            public int getCount(){
                return  namelist.size();
            }

            public  Object getItem(int mposition){
                return  namelist.get(mposition);
            }

            public long getItemId(int mposition) {
                return mposition;
            }

            //重写getView方法
            @Override
            public View getView(final int position, View converView, ViewGroup parent){
                View view=getLayoutInflater().inflate(R.layout.collection_list_item,null);
                TextView text1=(TextView)view.findViewById(R.id.Text1);
                ImageView image1=(ImageView)view.findViewById(R.id.image1);
                TextView text2=(TextView)view.findViewById(R.id.Text2);
                text1.setText(namelist.get(position));
                text2.setText(pricelist.get(position));
                image1.setBackground(imagelist.get(position));
//                //ListView 移除事件
                TextView text3 = (TextView)view.findViewById(R.id.Text3);
                text3.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int game_id = gameidlist.get(position);
                        new deletecollectionTask().execute(game_id);
                        Toast.makeText(siderbar_myCollection.this, "删除成功！", Toast.LENGTH_SHORT).show();
                        Intent intent=new Intent(siderbar_myCollection.this, siderbar_myCollection.class);
                        intent.putExtra("user_id",user_id);
                        startActivity(intent);
                        finish();

                    }
                });

                return view;
            }
        }
        //获取收藏
        public class getCollectionTask extends AsyncTask {
                String path="http://10.7.89.239:8080/YQY/GetCollectionServlet";
//            String path="http://192.168.0.101:8080/YQY/GetCollectionServlet";
            @Override
            protected Object doInBackground(Object[] objects) {
                try {
                    URL url = new URL(path+"?user_id="+user_id);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(5000);
                    int code = connection.getResponseCode();
                    if(code==200){
                        InputStream is = connection.getInputStream();
                        BufferedReader br = new BufferedReader(new InputStreamReader(is));
                        String s = br.readLine();
                        JSONArray ja = new JSONArray(s);
                        namelist = new ArrayList<>();
                        pricelist = new ArrayList<>();
                        imagelist = new ArrayList<>();
                        pathlist = new ArrayList<>();
                        gameidlist = new ArrayList<>();
                        for(int i=0;i<ja.length();i++){
                            String imagePath = "http://10.7.89.239:8080/YQY/images/"+ja.getJSONObject(i).getString("game_image");
//                            String imagePath = "http://192.168.0.101:8080/YQY/images/"+ja.getJSONObject(i).getString("game_image");
                            namelist.add(ja.getJSONObject(i).getString("game_name"));
                            gameidlist.add(ja.getJSONObject(i).getInt("game_id"));
                            pricelist.add(ja.getJSONObject(i).getString("game_price"));
                            pathlist.add(imagePath);
                        }
                        Log.e("123",""+namelist.size());
                        for(int i=0;i<pathlist.size();i++){
                            imagelist.add(Drawable.createFromStream(
                                    new URL(pathlist.get(i)).openStream(), "1"));
                        }

                        return s;
                    }
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return null;
            }
            protected void onPostExecute(Object o) {
                super.onPostExecute(o);
                listView.setAdapter(new MyBaseAdapter());
            }
        }
    public class deletecollectionTask extends AsyncTask{

        @Override
        protected Object doInBackground(Object[] objects) {
            String path="http://10.7.89.239:8080/YQY/DeleteCollectionServlet";
//            String path="http://192.168.0.101:8080/YQY/DeleteCollectionServlet";
            try {
                int game_id = Integer.parseInt(objects[0].toString());
                URL url = new URL(path+"?user_id="+user_id+"&game_id="+game_id);
                Log.e("deleteTask",""+game_id);
                Log.e("String",""+objects[0].toString());
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                int code = connection.getResponseCode();
                if(code==200){
                    InputStream is = connection.getInputStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    String s = br.readLine();
                    return s;
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}
