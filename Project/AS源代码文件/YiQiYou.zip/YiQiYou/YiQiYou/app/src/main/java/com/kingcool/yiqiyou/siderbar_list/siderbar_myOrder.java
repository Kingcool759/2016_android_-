package com.kingcool.yiqiyou.siderbar_list;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.kingcool.yiqiyou.MainActivity;
import com.kingcool.yiqiyou.R;
import com.kingcool.yiqiyou.ShoppingCartActivity;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class siderbar_myOrder extends AppCompatActivity {
    //ListView
    private ListView listView;
    private ArrayList<Integer> orderidlist;
    private List<String> pricelist;
    private List<String> timelist;
    private List<String> pathlist;
    private List<Drawable> imagelist;
    private String user_id;
    private MyBaseAdapter myBaseAdapter;
    Boolean lvchange = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.siderbar_my_order);

        Intent intent = getIntent();
        user_id = intent.getStringExtra("user_id");

        new getOrderTask().execute("未付款");

        LinearLayout linearLayout = findViewById(R.id.myorder_back);
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(siderbar_myOrder.this, MainActivity.class);
                intent.putExtra("user_id",user_id);
                startActivity(intent);
                finish();
            }
        });

        Button button1 = findViewById(R.id.btn_order_unpaid);
        Button button2 = findViewById(R.id.btn_order_paid);
        Button button3 = findViewById(R.id.btn_order_all);
        button1.setOnClickListener(onClickListener);
        button2.setOnClickListener(onClickListener);
        button3.setOnClickListener(onClickListener);

        //ListView
        listView = findViewById(R.id.lv_myorder);

    }
    //自定义适配器
    class MyBaseAdapter extends BaseAdapter {
        private ArrayList<Integer> olist;
        @SuppressWarnings("unchecked")
        public void setDeviceList(ArrayList<Integer> list) {
            if (list != null) {
                olist = (ArrayList<Integer>) list.clone();
                notifyDataSetChanged();
            }
        }

        public int getCount(){
            return  olist.size();
        }

        public  Object getItem(int mposition){
            return  olist.get(mposition);
        }

        public long getItemId(int mposition) {
            return mposition;
        }

        //重写getView方法
        @Override
        public View getView(final int position, View converView, ViewGroup parent){
//            View view=View.inflate(view.getContext(),R.layout.friends_list_item,null);
            View view=getLayoutInflater().inflate(R.layout.myorder_list_item,null);
            TextView tv_id=(TextView)view.findViewById(R.id.Text1);
            ImageView imageView=(ImageView)view.findViewById(R.id.image1);
            TextView tv_time=(TextView)view.findViewById(R.id.Text2);
            TextView tv_sprice=(TextView)view.findViewById(R.id.tv_sprice);
            tv_id.setText(String.valueOf(orderidlist.get(position)));
            tv_time.setText(timelist.get(position));
            tv_sprice.setText(pricelist.get(position));
            imageView.setBackground(imagelist.get(position));

//            //ListView 移除事件
//            TextView text3 = (TextView)view.findViewById(R.id.Text3);
//            text3.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    int order_id = orderidlist.get(position);
//                    new deleteTask().execute(order_id);
//                    Toast.makeText(siderbar_myOrder.this, "删除成功！", Toast.LENGTH_SHORT).show();
//                    Intent intent=new Intent(siderbar_myOrder.this, siderbar_myOrder.class);
//                    intent.putExtra("user_id",user_id);
//                    startActivity(intent);
//                    finish();
//                }
//            });
            //ListView 支付事件
            Button button = (Button)view.findViewById(R.id.btn_pay);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int order_id = orderidlist.get(position);
                    new payTask().execute(order_id);

                    Intent intent=new Intent(siderbar_myOrder.this, siderbar_myOrder.class);
                    intent.putExtra("user_id",user_id);
                    startActivity(intent);
                    finish();
                }
            });
            return view;
        }
    }


    //onClickListener
    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.btn_order_unpaid:
                    new getOrderTask().execute("未付款");
                    break;
                case R.id.btn_order_paid:
                    new getOrderTask().execute("已支付");
                    break;
                case R.id.btn_order_all:
                    new getOrderTask().execute("全部订单");
                    break;
            }
        }
    };


    //获得用户订单
    public class getOrderTask extends AsyncTask{

        @Override
        protected Object doInBackground(Object[] objects) {
            try {
                String order_state = objects[0].toString();
//                String path="http://10.222.184.97:8080/YQY/GetOrderServlet";
                String path="http://10.7.89.239:8080/YQY/GetOrderServlet";
                URL url = new URL(path+"?user_id="+user_id+"&order_state="+order_state);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                int code = connection.getResponseCode();
                    if(code==200){
                    InputStream is = connection.getInputStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    String s = br.readLine();
                    JSONArray ja = new JSONArray(s);
                    orderidlist = new ArrayList<>();
                    timelist = new ArrayList<>();
                    pathlist = new ArrayList<>();
                    imagelist = new ArrayList<>();
                    pricelist = new ArrayList<>();
                    for(int i=0;i<ja.length();i++){
                        pathlist.add(ja.getJSONObject(i).getString("order_image"));
                        orderidlist.add(ja.getJSONObject(i).getInt("order_id"));
                        timelist.add(ja.getJSONObject(i).getString("add_time"));
                        pricelist.add(ja.getJSONObject(i).getString("sumprice"));
                    }
                    Log.e("pathlist",""+pathlist);
                    for(int j=0;j<pathlist.size();j++){
                        imagelist.add(Drawable.createFromStream(
                                new URL(pathlist.get(j)).openStream(), "1"));
                    }
                        Log.e("imagelist",""+imagelist);
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);


            if(lvchange==false){
                myBaseAdapter = new MyBaseAdapter();
                myBaseAdapter.setDeviceList(orderidlist);
                listView.setAdapter(myBaseAdapter);
                lvchange = true;
            }else {
                myBaseAdapter.setDeviceList(orderidlist);
            }
        }
    }

    //删除订单
    public class deleteTask extends AsyncTask{
        @Override
        protected Object doInBackground(Object[] objects) {

//            String path=" http://10.222.184.97:8080/YQY/DeleteOrderServlet";
            String path="http://10.7.89.239:8080/YQY/DeleteOrderServlet";
            try {
                int order_id = Integer.parseInt(objects[0].toString());
                URL url = new URL(path+"?user_id="+user_id+"&order_id="+order_id);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                int code = connection.getResponseCode();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
    //支付订单
    public class payTask extends AsyncTask{
        @Override
        protected Object doInBackground(Object[] objects) {

//            String path=" http://10.222.184.97:8080/YQY/PayOrderServlet";
            String path="http://10.7.89.239:8080/YQY/PayOrderServlet";
            try {
                int order_id = Integer.parseInt(objects[0].toString());
                URL url = new URL(path+"?user_id="+user_id+"&order_id="+order_id);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                int code = connection.getResponseCode();
                if(code==200) {
                    InputStream is = connection.getInputStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    String s = br.readLine();
                    return s;
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            String s = (String)o;
            Toast.makeText(siderbar_myOrder.this, s, Toast.LENGTH_SHORT).show();
        }
    }
}
