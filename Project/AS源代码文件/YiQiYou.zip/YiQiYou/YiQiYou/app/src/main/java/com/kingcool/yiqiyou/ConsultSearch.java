package com.kingcool.yiqiyou;

import android.bluetooth.BluetoothClass;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class ConsultSearch extends AppCompatActivity {
    private ImageView ivBack;
    private EditText etSearch;
    private TextView tvCancel;
    private ListView lvSearch;
    private ArrayList<String> titlelist;
    private List<Integer>idlist;
    Boolean lvchange = false;
    SearchAdapter sa;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.consult_search);
        setViews();
        //返回键
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        //取消键清空EditView
        tvCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {tvCancel = findViewById(R.id.tv_cancel);
                etSearch.setText("");
            }
        });
        //键盘回车键的点击事件
        etSearch.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == event.KEYCODE_ENTER) {
                    // do some your things
                    //执行异步任务
                    String etstr = etSearch.getText().toString();
                    String path = "http://10.7.89.239:8080/YQY/GetConsultTitle";
//                    String path = "http://192.168.0.101:8080/YQY/GetConsultTitle";
                    Log.e("12323",""+etstr);
                    new GetConsultTitle().execute(etstr,path);
                }
                return false;
            }
        });
    }
    private void setViews(){
        ivBack = findViewById(R.id.back);
        etSearch = findViewById(R.id.et_search);
        tvCancel = findViewById(R.id.tv_cancel);
        lvSearch = findViewById(R.id.lv_search);
    }
    //搜索listview适配器
    class SearchAdapter extends BaseAdapter{
        private ArrayList<String> tlist;
        @SuppressWarnings("unchecked")
        public void setDeviceList(ArrayList<String> list) {
            if (list != null) {
                tlist = (ArrayList<String>) list.clone();
                notifyDataSetChanged();
            }
        }
        @Override
        public int getCount() {
            return tlist.size();
        }

        @Override
        public long getItemId(int mposition) {
            return mposition;
        }

        @Override
        public Object getItem(int mposition) {
            return tlist.get(mposition);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            //加载布局为一个视图
            View view = getLayoutInflater().inflate(R.layout.consult_search_item,null);
            //获取控件id
            TextView tvItem= (TextView) view.findViewById(R.id.tv_search);
            tvItem.setText(tlist.get(position));
            return view;
        }
    }
    //异步任务
    class GetConsultTitle extends AsyncTask {
        @Override
        protected Object doInBackground(Object[] objects) {
            String etstr = objects[0].toString();
            String path = objects[1].toString();
            try {
                URL url = new URL(path+"?etstr="+etstr);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                int code = connection.getResponseCode();
                if(code==200){
                    InputStream is = connection.getInputStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    String s = br.readLine();
                    //解析JSON数据
                    JSONArray ja = new JSONArray(s);
                    titlelist = new ArrayList<>();
                    idlist = new ArrayList<>();
                    for(int i=0;i<ja.length();i++){
                        titlelist.add(ja.getJSONObject(i).getString("consult_title"));
                        Log.e("000",""+titlelist);
                        idlist.add(ja.getJSONObject(i).getInt("consult_id"));
                        Log.e("111",""+idlist);
                    }
                }
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            //返回值判断搜索结果是否为空
            int co = 0;
            if(idlist.size()!=0){
                co = 1;
            }else {
                co = 0;
            }
            return co;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            if(lvchange==false){
                sa = new SearchAdapter();
                sa.setDeviceList(titlelist);
                lvSearch.setAdapter(sa);
                lvchange = true;
            }else {
                sa.setDeviceList(titlelist);
            }

            //点击一个listview的item组件将id传递给ConsultDetails
            lvSearch.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Intent intent9 = new Intent(ConsultSearch.this,ConsultDetails.class);
                    intent9.putExtra("id",String.valueOf(idlist.get(position)));
                    startActivity(intent9);
                    finish();
                }
            });
            if(o.equals(1)){
                Toast.makeText(ConsultSearch.this,"为您查到以上结果！", Toast.LENGTH_SHORT).show();
            }else {
                Toast.makeText(ConsultSearch.this,"抱歉，未找到相关资讯。", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
