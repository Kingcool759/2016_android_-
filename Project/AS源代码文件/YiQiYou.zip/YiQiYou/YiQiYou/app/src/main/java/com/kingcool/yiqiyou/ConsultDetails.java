package com.kingcool.yiqiyou;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.kingcool.yiqiyou.Entity.Consult;
import com.kingcool.yiqiyou.Fragments.ConsultFragment;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class ConsultDetails extends AppCompatActivity {
    private String id;
    private TextView tvTitle;
    private TextView tvContent;
    private ImageView ivImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.consult_details);
        tvTitle = (TextView) findViewById(R.id.consult_title);
        tvContent = (TextView) findViewById(R.id.consult_content);
        ivImage = (ImageView) findViewById(R.id.consult_image);
        //不进行Intent的跳转，只携带id数据,服务器根据获取的id在数据库查找数据
        Intent intent1 = getIntent();
        id = intent1.getStringExtra("id");
        Log.e("intent_i",""+id);
        //顶部返回键主界面跳转
        LinearLayout linearLayout = findViewById(R.id.back_consult);
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        //执行异步任务getConsultDetails，从服务器端取JSON数据
        String path="http://10.7.89.239:8080/YQY/GetConsultDetailsServlet"; //404教室
//        String path="http://192.168.0.101:8080/YQY/GetConsultDetailsServlet"; //宿舍
        new getConsultDetails().execute(id,path);
    }
    //异步任务，从服务器端获取mysql数据
    public class getConsultDetails extends AsyncTask{
        @Override
        protected Object doInBackground(Object[] objects) {
            String id = objects[0].toString();
            String path = objects[1].toString();
            URL url = null;
            try {
                url = new URL(path+"?id="+id);
                HttpURLConnection conn =(HttpURLConnection)url.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("contentType","UTF-8");
                conn.setConnectTimeout(5000);
                int code = conn.getResponseCode();
                if(code==200){
                    InputStream is = conn.getInputStream();//用io流于web后台进行数据交互
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));//字节流转字符流
                    String res = br.readLine();//读出每一行的数据
                    //--解析JSON数据--//
                    //通过JSON字符串创建JSONObject的实例
                    JSONObject jos = new JSONObject(res);
                    //从JSONObject对象中取出值，显示在textview中
                    tvTitle.setText(jos.getString("title"));
                    Log.e("test",""+tvTitle.getText().toString());
                    tvContent.setText(jos.getString("content"));
                    String imagePath = "http://10.7.89.239:8080/YQY/images/"+jos.getString("image");
//                    String imagePath = "http://192.168.0.101:8080/YQY/images/"+jos.getString("image");
                    Log.e("imagepath",""+imagePath);
                    //将保存在服务器的图片的URL转换成drawable
                    Drawable drawable = Drawable.createFromStream(
                            new URL(imagePath).openStream(),"1");
                    return drawable;//返回读出的每一行的数据
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            Drawable drawable = (Drawable) o;
            ivImage.setBackground(drawable);
        }
    }
}


