package com.kingcool.yiqiyou.Fragments;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.kingcool.yiqiyou.GameClassActivity;
import com.kingcool.yiqiyou.R;
import com.kingcool.yiqiyou.ShopDetailActivity;
import com.kingcool.yiqiyou.ShoppingCartActivity;

import java.nio.channels.InterruptedByTimeoutException;

public class ShopFragment extends Fragment {
    private Button button1;
    private Button button2;
    private Button button3;
    private Button button4;
    private Intent intent;
    private String user_id;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.shop_fragment_layout, container, false);
        Intent intent = getActivity().getIntent();
        user_id = intent.getStringExtra("user_id");
        //绑定
        setClick(view);
        ImageButton imageButton = view.findViewById(R.id.tv_cart_home);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), ShoppingCartActivity.class);
                intent.putExtra("user_id",user_id);
                startActivity(intent);
            }
        });

        return view;
    }

    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.btn_1:
                    intent = new Intent(getActivity(), GameClassActivity.class);
                    intent.putExtra("类别","策略类");
                    intent.putExtra("user_id",user_id);
                    startActivity(intent);
                    break;
                case R.id.btn_2:
                    intent = new Intent(getActivity(), GameClassActivity.class);
                    intent.putExtra("类别","动作类");
                    intent.putExtra("user_id",user_id);
                    startActivity(intent);
                    break;
                case R.id.btn_3:
                    intent = new Intent(getActivity(), GameClassActivity.class);
                    intent.putExtra("类别","射击类");
                    intent.putExtra("user_id",user_id);
                    startActivity(intent);
                    break;
                case R.id.btn_4:
                    intent = new Intent(getActivity(), GameClassActivity.class);
                    intent.putExtra("类别","竞速类");
                    intent.putExtra("user_id",user_id);
                    startActivity(intent);
                    break;
                case R.id.ib_cr:
                    intent = new Intent(getActivity(), ShopDetailActivity.class);
                    intent.putExtra("id","17");
                    intent.putExtra("user_id",user_id);
                    startActivity(intent);
                    break;
                case R.id.ib_jc:
                    intent = new Intent(getActivity(), ShopDetailActivity.class);
                    intent.putExtra("id","19");
                    intent.putExtra("user_id",user_id);
                    startActivity(intent);
                    break;
                case R.id.ib_prey:
                    intent = new Intent(getActivity(), ShopDetailActivity.class);
                    intent.putExtra("id","20");
                    intent.putExtra("user_id",user_id);
                    startActivity(intent);
                    break;
                case R.id.iv_ac:
                    intent = new Intent(getActivity(), ShopDetailActivity.class);
                    intent.putExtra("id","1");
                    intent.putExtra("user_id",user_id);
                    startActivity(intent);
                    break;
                case R.id.iv_pubg:
                    intent = new Intent(getActivity(), ShopDetailActivity.class);
                    intent.putExtra("id","6");
                    intent.putExtra("user_id",user_id);
                    startActivity(intent);
                     break;
                case R.id.iv_dota2:
                    intent = new Intent(getActivity(), ShopDetailActivity.class);
                    intent.putExtra("id","21");
                    intent.putExtra("user_id",user_id);
                    startActivity(intent);
                    break;
                case R.id.iv_dmc5:
                    intent = new Intent(getActivity(), ShopDetailActivity.class);
                    intent.putExtra("id","12");
                    intent.putExtra("user_id",user_id);
                    startActivity(intent);
                    break;
                case R.id.iv_hff:
                    intent = new Intent(getActivity(), ShopDetailActivity.class);
                    intent.putExtra("id","23");
                    intent.putExtra("user_id",user_id);
                    startActivity(intent);
                    break;
                case R.id.iv_in:
                    intent = new Intent(getActivity(), ShopDetailActivity.class);
                    intent.putExtra("id","18");
                    intent.putExtra("user_id",user_id);
                    startActivity(intent);
                    break;
                case R.id.iv_prey:
                    intent = new Intent(getActivity(), ShopDetailActivity.class);
                    intent.putExtra("id","20");
                    intent.putExtra("user_id",user_id);
                    startActivity(intent);
                    break;
                case R.id.iv_thq:
                    intent = new Intent(getActivity(), ShopDetailActivity.class);
                    intent.putExtra("id","22");
                    intent.putExtra("user_id",user_id);
                    startActivity(intent);
                    break;
            }
        }
    };

    public void setClick(View view){
        button1 = view.findViewById(R.id.btn_1);
        button2 = view.findViewById(R.id.btn_2);
        button3 = view.findViewById(R.id.btn_3);
        button4 = view.findViewById(R.id.btn_4);
        button1.setOnClickListener(onClickListener);
        button2.setOnClickListener(onClickListener);
        button3.setOnClickListener(onClickListener);
        button4.setOnClickListener(onClickListener);


        ImageButton ib_cr = view.findViewById(R.id.ib_cr);
        ImageButton ib_jc = view.findViewById(R.id.ib_jc);
        ImageButton ib_prey = view.findViewById(R.id.ib_prey);
        ImageView iv_ac = view.findViewById(R.id.iv_ac);
        ImageView iv_pubg = view.findViewById(R.id.iv_pubg);
        ImageView iv_dota2 = view.findViewById(R.id.iv_dota2);
        ImageView iv_dmc5 = view.findViewById(R.id.iv_dmc5);
        ImageView iv_hff = view.findViewById(R.id.iv_hff);
        ImageView iv_in = view.findViewById(R.id.iv_in);
        ImageView iv_prey = view.findViewById(R.id.iv_prey);
        ImageView iv_thq = view.findViewById(R.id.iv_thq);

        ib_cr.setOnClickListener(onClickListener);
        ib_jc.setOnClickListener(onClickListener);
        ib_prey.setOnClickListener(onClickListener);
        iv_ac.setOnClickListener(onClickListener);
        iv_pubg.setOnClickListener(onClickListener);
        iv_dota2.setOnClickListener(onClickListener);
        iv_dmc5.setOnClickListener(onClickListener);
        iv_hff.setOnClickListener(onClickListener);
        iv_in.setOnClickListener(onClickListener);
        iv_prey.setOnClickListener(onClickListener);
        iv_thq.setOnClickListener(onClickListener);
    }

}
