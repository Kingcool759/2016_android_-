package com.kingcool.yiqiyou.siderbar_list;

import android.app.Dialog;
import android.content.Intent;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.kingcool.yiqiyou.MainActivity;
import com.kingcool.yiqiyou.R;

import java.util.ArrayList;
import java.util.List;

import com.kingcool.yiqiyou.PickerView;

public class siderbar_myInformation extends AppCompatActivity {

    //----------------
    private Dialog upSex;
    private String selectSex;
    //----------------

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.siderbar_my_information);
        final EditText etName = findViewById(R.id.my_et_name);
        LinearLayout ll2 = findViewById(R.id.my_ll_sex);
        ll2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectSex();
            }
        });
        LinearLayout linearLayout = findViewById(R.id.myinfo_back);
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(siderbar_myInformation.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }


    //----------------

    private void selectSex() {
        upSex = new Dialog(siderbar_myInformation.this, R.style.dialog);
        View defaultView = LayoutInflater.from(this).inflate(
                R.layout.picker_dialog, null);
        PickerView picker = (PickerView) defaultView.findViewById(R.id.pickerView);
        Button finish = (Button) defaultView
                .findViewById(R.id.finish);
        Button cancel = (Button) defaultView
                .findViewById(R.id.cancel);
        List<String> data = new ArrayList<String>();
        data.add("男");
        data.add("女");
        picker.setData(data);

        picker.setOnSelectListener(new PickerView.onSelectListener() {

            @Override
            public void onSelect(String text) {
               selectSex = text;
            }
        });
        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                upSex.dismiss();
                TextView textView = findViewById(R.id.my_tv_sex);
                    textView.setText(selectSex);
            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                upSex.dismiss();
            }
        });

        upSex.setContentView(defaultView);

        upSex.setCancelable(true);
        upSex.setCanceledOnTouchOutside(true);
        upSex.show();
        WindowManager windowManager = siderbar_myInformation.this.getWindowManager();
        Display display = windowManager.getDefaultDisplay();
        WindowManager.LayoutParams lp = upSex.getWindow().getAttributes();
        lp.width = (int) (display.getWidth());
        upSex.getWindow().setAttributes(lp);
        upSex.getWindow().setGravity(Gravity.BOTTOM);
    }
    //----------------
}
